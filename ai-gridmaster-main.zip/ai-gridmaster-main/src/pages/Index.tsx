
import { useState } from "react";
import GridOverview from "@/components/GridOverview";
import Metrics from "@/components/Metrics";
import AlertPanel from "@/components/AlertPanel";
import SystemHealth from "@/components/SystemHealth";
import PowerAnalytics from "@/components/PowerAnalytics";
import { Button } from "@/components/ui/button";
import { MenuIcon, XIcon, Settings } from "lucide-react";

const Index = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      {/* Sidebar */}
      <div
        className={`fixed top-0 left-0 h-full w-64 bg-gray-800 shadow-lg transform transition-transform duration-300 ease-in-out ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="p-6">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-xl font-semibold text-gray-100">Smart Grid</h1>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden text-gray-400 hover:text-gray-100"
            >
              <XIcon className="h-6 w-6" />
            </Button>
          </div>
          <nav className="space-y-4">
            <a
              href="#overview"
              className="block px-4 py-2 text-gray-300 hover:bg-gray-700 rounded-lg transition-colors"
            >
              Overview
            </a>
            <a
              href="#metrics"
              className="block px-4 py-2 text-gray-300 hover:bg-gray-700 rounded-lg transition-colors"
            >
              Metrics
            </a>
            <a
              href="#alerts"
              className="block px-4 py-2 text-gray-300 hover:bg-gray-700 rounded-lg transition-colors"
            >
              Alerts
            </a>
            <a
              href="#health"
              className="block px-4 py-2 text-gray-300 hover:bg-gray-700 rounded-lg transition-colors"
            >
              System Health
            </a>
            <a
              href="#analytics"
              className="block px-4 py-2 text-gray-300 hover:bg-gray-700 rounded-lg transition-colors"
            >
              Power Analytics
            </a>
            <a
              href="#settings"
              className="block px-4 py-2 text-gray-300 hover:bg-gray-700 rounded-lg transition-colors"
            >
              Settings
            </a>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div
        className={`transition-all duration-300 ${
          sidebarOpen ? "ml-64" : "ml-0"
        }`}
      >
        <header className="bg-gray-800 shadow-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex justify-between items-center">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSidebarOpen(true)}
                className={`${
                  sidebarOpen ? "hidden" : "block"
                } lg:hidden text-gray-400 hover:text-gray-100`}
              >
                <MenuIcon className="h-6 w-6" />
              </Button>
              <h1 className="text-xl font-semibold text-gray-100">Dashboard</h1>
              <div className="flex items-center space-x-4">
                <span className="flex items-center px-3 py-1 rounded-full bg-green-900 text-green-100 text-sm font-medium">
                  System Online
                </span>
                <Button variant="ghost" size="icon" className="text-gray-400 hover:text-gray-100">
                  <Settings className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <GridOverview />
            <Metrics />
            <AlertPanel />
          </div>
          <div className="mt-6">
            <SystemHealth />
          </div>
          <div className="mt-6" id="analytics">
            <PowerAnalytics />
          </div>
        </main>
      </div>
    </div>
  );
};

export default Index;
