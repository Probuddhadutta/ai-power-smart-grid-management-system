
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, AlertTriangle, Info, CheckCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

interface Alert {
  id: number;
  type: "warning" | "info" | "success";
  message: string;
  time: string;
  details: string;
}

const AlertPanel = () => {
  const { toast } = useToast();
  const [alerts, setAlerts] = useState<Alert[]>([
    {
      id: 1,
      type: "warning",
      message: "High load detected in Sector A",
      time: "2 minutes ago",
      details: "Load exceeding 85% threshold. Consider redistributing power.",
    },
    {
      id: 2,
      type: "info",
      message: "Maintenance scheduled for tomorrow",
      time: "1 hour ago",
      details: "Routine maintenance on transformers in Sector B.",
    },
    {
      id: 3,
      type: "success",
      message: "System optimization completed",
      time: "3 hours ago",
      details: "Grid efficiency improved by 2.5%",
    },
  ]);

  // Simulate new alerts
  useEffect(() => {
    const interval = setInterval(() => {
      const randomAlert: Alert = {
        id: Date.now(),
        type: ["warning", "info", "success"][Math.floor(Math.random() * 3)] as "warning" | "info" | "success",
        message: ["Voltage fluctuation detected", "Backup systems checked", "Load balancing completed"][
          Math.floor(Math.random() * 3)
        ],
        time: "Just now",
        details: "AI system detected anomaly pattern.",
      };

      setAlerts(prev => [randomAlert, ...prev.slice(0, 2)]);
      
      // Show toast for warning alerts
      if (randomAlert.type === "warning") {
        toast({
          title: "Warning Alert",
          description: randomAlert.message,
          variant: "destructive",
        });
      }
    }, 15000);

    return () => clearInterval(interval);
  }, [toast]);

  return (
    <Card className="col-span-2 lg:col-span-1 bg-gray-800 border-gray-700">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-semibold flex items-center gap-2 text-gray-100">
            <Bell className="h-5 w-5 text-amber-400" />
            Recent Alerts
          </CardTitle>
          <Button variant="outline" size="sm" className="text-gray-300 border-gray-600">
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {alerts.map((alert) => (
            <div
              key={alert.id}
              className="flex items-start p-3 bg-gray-700 rounded-lg border border-gray-600"
            >
              <div className="flex-shrink-0 mt-1">
                {alert.type === "warning" ? (
                  <AlertTriangle className="h-5 w-5 text-amber-400" />
                ) : alert.type === "info" ? (
                  <Info className="h-5 w-5 text-blue-400" />
                ) : (
                  <CheckCircle className="h-5 w-5 text-green-400" />
                )}
              </div>
              <div className="ml-3 flex-1">
                <p className="text-sm text-gray-100">{alert.message}</p>
                <p className="text-xs text-gray-400 mt-1">{alert.details}</p>
                <p className="text-xs text-gray-500 mt-1">{alert.time}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default AlertPanel;
