
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";

interface SystemStatus {
  name: string;
  status: string;
  health: number;
  details: string;
}

const SystemHealth = () => {
  const [systems, setSystems] = useState<SystemStatus[]>([
    {
      name: "Power Distribution",
      status: "Operational",
      health: 98,
      details: "All substations functioning normally",
    },
    {
      name: "Grid Security",
      status: "Optimal",
      health: 100,
      details: "No security breaches detected",
    },
    {
      name: "Load Balancing",
      status: "Good",
      health: 92,
      details: "Minor optimization needed in Sector C",
    },
    {
      name: "Network Communication",
      status: "Stable",
      health: 95,
      details: "Latency within acceptable range",
    },
  ]);

  // Simulate real-time system health updates
  useEffect(() => {
    const interval = setInterval(() => {
      setSystems(prev => 
        prev.map(system => ({
          ...system,
          health: Math.max(85, Math.min(100, system.health + (Math.random() - 0.5) * 2)),
          status: system.health >= 95 ? "Optimal" : system.health >= 90 ? "Good" : "Warning",
          details: system.health >= 95 
            ? "System performing optimally"
            : system.health >= 90
            ? "Minor optimizations possible"
            : "Attention required"
        }))
      );
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-semibold flex items-center gap-2 text-gray-100">
            <Shield className="h-5 w-5 text-green-400" />
            System Health
          </CardTitle>
          <Button variant="outline" size="sm" className="text-gray-300 border-gray-600">
            <Settings className="w-4 h-4 mr-2" />
            Configure
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {systems.map((system) => (
            <div
              key={system.name}
              className="p-4 bg-gray-700 rounded-lg border border-gray-600"
            >
              <h3 className="text-sm font-medium text-gray-100">
                {system.name}
              </h3>
              <div className="mt-2 flex items-baseline gap-2">
                <span
                  className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    system.health >= 95
                      ? "bg-green-900 text-green-100"
                      : system.health >= 90
                      ? "bg-blue-900 text-blue-100"
                      : "bg-amber-900 text-amber-100"
                  }`}
                >
                  {system.status}
                </span>
                <span className="text-sm text-gray-400">{system.health.toFixed(1)}%</span>
              </div>
              <div className="mt-3 w-full bg-gray-600 rounded-full h-1.5">
                <div
                  className={`h-1.5 rounded-full ${
                    system.health >= 95
                      ? "bg-green-400"
                      : system.health >= 90
                      ? "bg-blue-400"
                      : "bg-amber-400"
                  }`}
                  style={{ width: `${system.health}%` }}
                />
              </div>
              <p className="mt-2 text-xs text-gray-400">{system.details}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default SystemHealth;
