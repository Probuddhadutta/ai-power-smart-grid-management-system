
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Power, Server, Signal, Zap, Clock, Activity } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { getPredictions } from "@/services/predictionApi";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const GridOverview = () => {
  const { toast } = useToast();
  const [powerOutput, setPowerOutput] = useState({ value: 1.2, change: 12 });
  const [gridLoad, setGridLoad] = useState({ current: 78, peak: 85 });
  const [efficiency, setEfficiency] = useState({ value: 94.5, status: "Optimal" });
  const [recommendations, setRecommendations] = useState<string[]>([]);
  const [visualizations, setVisualizations] = useState({
    visualization: '',
    stability: '',
    dataRepresentation: ''
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchPredictions = async () => {
      try {
        setIsLoading(true);
        const currentData = {
          power_output: powerOutput.value,
          grid_load: gridLoad.current,
          efficiency: efficiency.value,
          timestamp: new Date().toISOString(),
        };

        const predictions = await getPredictions(currentData);

        // Update state with predictions
        setGridLoad(prev => ({
          ...prev,
          peak: Math.max(prev.peak, predictions.predicted_load)
        }));

        setEfficiency(prev => ({
          value: predictions.efficiency_score,
          status: predictions.efficiency_score > 95 ? "Excellent" : 
                 predictions.efficiency_score > 90 ? "Optimal" : "Good"
        }));

        setRecommendations(predictions.recommendations);
        
        // Set visualization URLs from backend
        setVisualizations({
          visualization: predictions.visualization_url,
          stability: predictions.stability_url,
          dataRepresentation: predictions.data_representation_url
        });

        if (predictions.anomaly_detected) {
          toast({
            title: "Anomaly Detected",
            description: "System has detected unusual patterns in power distribution.",
            variant: "destructive",
          });
        }
        
        setIsLoading(false);
      } catch (error) {
        console.error('Error updating predictions:', error);
        setIsLoading(false);
        toast({
          title: "Connection Error",
          description: "Failed to connect to the analysis server",
          variant: "destructive",
        });
      }
    };

    // Initial fetch
    fetchPredictions();

    // Set up interval for regular updates
    const interval = setInterval(fetchPredictions, 30000); // Every 30 seconds

    return () => clearInterval(interval);
  }, [toast]);

  return (
    <Card className="col-span-2 bg-gray-800 border-gray-700">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-semibold flex items-center gap-2 text-gray-100">
            <Power className="h-5 w-5 text-teal-400" />
            Grid Overview
          </CardTitle>
          <Button variant="outline" size="sm" className="text-gray-300 border-gray-600">
            Configure
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <div className="flex items-center p-4 bg-gray-700 rounded-lg border border-gray-600">
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-teal-900">
              <Signal className="w-6 h-6 text-teal-400" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-300">Power Output</h3>
              <p className="text-2xl font-semibold text-gray-100">{powerOutput.value} GW</p>
              <p className="text-xs text-teal-400 mt-1">
                {powerOutput.change > 0 ? "↑" : "↓"} {Math.abs(powerOutput.change)}% from last hour
              </p>
            </div>
          </div>
          <div className="flex items-center p-4 bg-gray-700 rounded-lg border border-gray-600">
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-amber-900">
              <Server className="w-6 h-6 text-amber-400" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-300">Grid Load</h3>
              <p className="text-2xl font-semibold text-gray-100">{gridLoad.current.toFixed(1)}%</p>
              <p className="text-xs text-amber-400 mt-1">Peak load: {gridLoad.peak}%</p>
            </div>
          </div>
          <div className="flex items-center p-4 bg-gray-700 rounded-lg border border-gray-600">
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-green-900">
              <Activity className="w-6 h-6 text-green-400" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-300">Efficiency</h3>
              <p className="text-2xl font-semibold text-gray-100">{efficiency.value}%</p>
              <p className="text-xs text-green-400 mt-1">{efficiency.status}</p>
            </div>
          </div>
        </div>
        
        <div className="mt-6">
          <Tabs defaultValue="insights" className="w-full">
            <TabsList className="grid grid-cols-4 bg-gray-700">
              <TabsTrigger value="insights" className="text-gray-300">Insights</TabsTrigger>
              <TabsTrigger value="visualization" className="text-gray-300">Visualization</TabsTrigger>
              <TabsTrigger value="stability" className="text-gray-300">Stability</TabsTrigger>
              <TabsTrigger value="representation" className="text-gray-300">Data Analysis</TabsTrigger>
            </TabsList>
            
            <TabsContent value="insights" className="p-4 bg-gray-700 rounded-lg border border-gray-600 mt-2">
              <h4 className="text-sm font-medium text-gray-300 mb-2">AI-Powered Insights</h4>
              {isLoading ? (
                <div className="flex justify-center items-center h-32">
                  <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-teal-500"></div>
                </div>
              ) : (
                <ul className="space-y-2 text-sm text-gray-400">
                  {recommendations.map((recommendation, index) => (
                    <li key={index} className="flex items-center gap-2">
                      {index === 0 && <Zap className="w-4 h-4 text-amber-400" />}
                      {index === 1 && <Clock className="w-4 h-4 text-teal-400" />}
                      {index === 2 && <Activity className="w-4 h-4 text-green-400" />}
                      {recommendation}
                    </li>
                  ))}
                </ul>
              )}
            </TabsContent>
            
            <TabsContent value="visualization" className="p-4 bg-gray-700 rounded-lg border border-gray-600 mt-2">
              <h4 className="text-sm font-medium text-gray-300 mb-2">Power Distribution Visualization</h4>
              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-teal-500"></div>
                </div>
              ) : visualizations.visualization ? (
                <div className="rounded-md overflow-hidden bg-gray-800 h-64 flex items-center justify-center">
                  <img 
                    src={visualizations.visualization} 
                    alt="Power Distribution Visualization" 
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
              ) : (
                <div className="h-64 flex items-center justify-center text-gray-400">
                  Visualization not available
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="stability" className="p-4 bg-gray-700 rounded-lg border border-gray-600 mt-2">
              <h4 className="text-sm font-medium text-gray-300 mb-2">Grid Stability Analysis</h4>
              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-teal-500"></div>
                </div>
              ) : visualizations.stability ? (
                <div className="rounded-md overflow-hidden bg-gray-800 h-64 flex items-center justify-center">
                  <img 
                    src={visualizations.stability} 
                    alt="Stability Analysis" 
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
              ) : (
                <div className="h-64 flex items-center justify-center text-gray-400">
                  Stability analysis not available
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="representation" className="p-4 bg-gray-700 rounded-lg border border-gray-600 mt-2">
              <h4 className="text-sm font-medium text-gray-300 mb-2">Data Pattern Representation</h4>
              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-teal-500"></div>
                </div>
              ) : visualizations.dataRepresentation ? (
                <div className="rounded-md overflow-hidden bg-gray-800 h-64 flex items-center justify-center">
                  <img 
                    src={visualizations.dataRepresentation} 
                    alt="Data Pattern Representation" 
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
              ) : (
                <div className="h-64 flex items-center justify-center text-gray-400">
                  Data representation not available
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </CardContent>
    </Card>
  );
};

export default GridOverview;
