
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, AreaChart } from "@tremor/react";
import { useState, useEffect } from "react";
import { getPowerData, analyzePowerData } from "@/services/predictionApi";
import { useToast } from "@/hooks/use-toast";

interface PowerData {
  timestamp: string;
  voltage: number;
  current: number;
  powerUsage: number;
  frequency: number;
}

const PowerAnalytics = () => {
  const { toast } = useToast();
  const [powerData, setPowerData] = useState<PowerData[]>([]);
  const [correlationData, setCorrelationData] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;

    const fetchData = async () => {
      try {
        const newPowerData = await getPowerData();
        
        if (!isMounted) return;

        setPowerData(prev => {
          const updated = [...prev, newPowerData].slice(-20);
          return updated;
        });

        const analysis = await analyzePowerData(newPowerData);
        
        if (!isMounted) return;

        setCorrelationData(analysis.correlations);
        
        if (analysis.predictions.efficiency_score < 90) {
          toast({
            title: "Low Efficiency Alert",
            description: `Current efficiency score: ${analysis.predictions.efficiency_score.toFixed(1)}%`,
            variant: "destructive",
          });
        }

        setError(null);
      } catch (err) {
        if (!isMounted) return;
        setError("Failed to fetch data. Please check your connection.");
        console.error('Error fetching data:', err);
        toast({
          title: "Connection Error",
          description: "Failed to connect to the analysis server",
          variant: "destructive",
        });
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    };

    // Initial fetch
    fetchData();

    // Set up polling interval
    const interval = setInterval(fetchData, 5000); // Poll every 5 seconds

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [toast]);

  const formattedData = powerData.map(data => ({
    timestamp: new Date(data.timestamp).toLocaleTimeString(),
    "Power Usage": data.powerUsage,
    "Voltage": data.voltage,
    "Current": data.current,
    "Frequency": data.frequency,
  }));

  if (error) {
    return (
      <div className="p-4 bg-red-900/20 border border-red-700 rounded-lg">
        <p className="text-red-400">{error}</p>
      </div>
    );
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="col-span-2 bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-100">
            Real-time Power Usage Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="h-72 flex items-center justify-center">
              <p className="text-gray-400">Loading data...</p>
            </div>
          ) : (
            <LineChart
              className="h-72 mt-4"
              data={formattedData}
              index="timestamp"
              categories={["Power Usage"]}
              colors={["rose"]}
              valueFormatter={(number: number) => `${number.toLocaleString()} kW`}
              yAxisWidth={60}
            />
          )}
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-100">
            Parameter Correlation
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="h-72 flex items-center justify-center">
              <p className="text-gray-400">Loading correlations...</p>
            </div>
          ) : (
            <AreaChart
              className="h-72 mt-4"
              data={correlationData}
              index="metric"
              categories={["correlation"]}
              colors={["teal"]}
              valueFormatter={(number: number) => `${(number * 100).toFixed(1)}%`}
            />
          )}
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-100">
            Grid Parameters
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="h-72 flex items-center justify-center">
              <p className="text-gray-400">Loading parameters...</p>
            </div>
          ) : (
            <div className="space-y-4">
              {powerData.length > 0 && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-gray-700 rounded-lg">
                    <p className="text-sm text-gray-400">Voltage</p>
                    <p className="text-2xl font-semibold text-gray-100">
                      {powerData[powerData.length - 1].voltage.toFixed(1)} V
                    </p>
                  </div>
                  <div className="p-4 bg-gray-700 rounded-lg">
                    <p className="text-sm text-gray-400">Current</p>
                    <p className="text-2xl font-semibold text-gray-100">
                      {powerData[powerData.length - 1].current.toFixed(1)} A
                    </p>
                  </div>
                  <div className="p-4 bg-gray-700 rounded-lg">
                    <p className="text-sm text-gray-400">Power Usage</p>
                    <p className="text-2xl font-semibold text-gray-100">
                      {powerData[powerData.length - 1].powerUsage.toFixed(0)} kW
                    </p>
                  </div>
                  <div className="p-4 bg-gray-700 rounded-lg">
                    <p className="text-sm text-gray-400">Frequency</p>
                    <p className="text-2xl font-semibold text-gray-100">
                      {powerData[powerData.length - 1].frequency.toFixed(2)} Hz
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default PowerAnalytics;
