
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AreaChart } from "@tremor/react";
import { useState, useEffect } from "react";

const Metrics = () => {
  const [chartData, setChartData] = useState([
    { date: "Jan", Load: 2400, Capacity: 3000 },
    { date: "Feb", Load: 1398, Capacity: 3000 },
    { date: "Mar", Load: 9800, Capacity: 10000 },
    { date: "Apr", Load: 3908, Capacity: 4000 },
    { date: "May", Load: 4800, Capacity: 5000 },
    { date: "Jun", Load: 3800, Capacity: 4000 },
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setChartData(prev => {
        const newData = [...prev];
        newData.forEach(item => {
          item.Load = Math.max(1000, item.Load + (Math.random() - 0.5) * 200);
        });
        return newData;
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <Card className="col-span-2 lg:col-span-1 bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-100">Energy Consumption</CardTitle>
      </CardHeader>
      <CardContent>
        <AreaChart
          className="h-72 mt-4"
          data={chartData}
          index="date"
          categories={["Load", "Capacity"]}
          colors={["teal", "rose"]}
          valueFormatter={(number: number) => `${number.toLocaleString()} MW`}
        />
      </CardContent>
    </Card>
  );
};

export default Metrics;
