
interface PowerData {
  timestamp: string;
  voltage: number;
  current: number;
  powerUsage: number;
  frequency: number;
}

interface PredictionResponse {
  predictions: {
    voltage_trend: string;
    load_forecast: number;
    efficiency_score: number;
  };
  correlations: Array<{
    metric: string;
    correlation: number;
  }>;
}

interface SystemData {
  power_output: number;
  grid_load: number;
  efficiency: number;
  timestamp: string;
}

interface PredictionResult {
  predicted_load: number;
  efficiency_score: number;
  recommendations: string[];
  anomaly_detected: boolean;
  visualization_url: string;
  stability_url: string;
  data_representation_url: string;
}

export async function getPowerData(): Promise<PowerData> {
  const response = await fetch('http://localhost:8000/power-data');
  if (!response.ok) {
    throw new Error('Failed to fetch power data');
  }
  return response.json();
}

export async function analyzePowerData(data: PowerData): Promise<PredictionResponse> {
  const response = await fetch('http://localhost:8000/analyze', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    throw new Error('Failed to analyze power data');
  }
  return response.json();
}

export async function getPredictions(data: SystemData): Promise<PredictionResult> {
  const response = await fetch('http://localhost:8000/predict', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    throw new Error('Failed to fetch predictions');
  }
  return response.json();
}
